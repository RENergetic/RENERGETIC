package com.inetum.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackinfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
